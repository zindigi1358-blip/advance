# Asset Discovery Engine — Module 1

> ⚠️ **AUTHORIZED USE ONLY** — Sirf apne ya client ke domain pe use karein jinka written permission ho.

---

## Step 1 — Files server pe copy karo

```bash
# Apne home folder mein project banao
mkdir -p ~/project/advance/asset-discovery
cd ~/project/advance/asset-discovery
```

Phir ZIP upload karke extract karo, ya seedha files copy karo.

---

## Step 2 — Permissions fix karo (ZAROORI)

```bash
# Saare files ka owner apne user ko banao
sudo chown -R ubuntu:ubuntu ~/project/

# Folders aur files ko readable banao
chmod -R 755 ~/project/advance/asset-discovery/
```

---

## Step 3 — Dependencies install karo

```bash
pip3 install aiohttp aiofiles dnspython
```

---

## Step 4 — Scan run karo

```bash
cd ~/project/advance/asset-discovery/module1

# Basic scan (apna domain):
python3 run.py --domain yourdomain.com --confirm

# GitHub token ke saath (zyada results):
python3 run.py --domain yourdomain.com --github-token ghp_xxxYOURTOKENxxx --confirm

# Sirf subdomains + tech (ports aur cloud skip karo):
python3 run.py --domain yourdomain.com --no-ports --no-cloud --confirm
```

> **Note:** `python` command nahi chalega Ubuntu pe — hamesha `python3` likhein

---

## Passive DNS Sources (Updated)

| Source | Status | Key Needed? |
|---|---|---|
| crt.sh (Certificate Transparency) | ✅ Working | No |
| HackerTarget | ✅ Working | No |
| AlienVault OTX | ✅ Working | No |
| VirusTotal | ✅ Working | No (basic) |
| RapidDNS | ✅ Working | No |
| DNS Bruteforce (wordlist) | ✅ Working | No |
| ThreatCrowd | ❌ Dead (removed) | — |

---

## Common Errors aur Fix

| Error | Fix |
|---|---|
| `PermissionError: discovery.log` | `sudo chown -R ubuntu:ubuntu ~/project/` |
| `Command 'python' not found` | `python3` likhein, `python` nahi |
| `ModuleNotFoundError: aiohttp` | `pip3 install aiohttp aiofiles dnspython` |
| `--confirm flag required` | Command mein `--confirm` add karein |

---

## Output

JSON report `~/project/advance/asset-discovery/module1/reports/` mein save hoga.

